/*:
 # Chapter Challenge: Combat Actions
 ---
 
 ### Tasks
 1. Create an enumeration called **ActionError** that adopts the **Error** protocol with three cases - **InsufficientMP**, **OutOfRange**, and **UnknownError**
 2. Declare a function called **attackEnemy** that takes in an integer named **mp** and a double named **distance** as parameters and returns an optional boolean.
 3. Mark **attackEnemy** as a throwable function
 4. Add two guard statements - if **mp** is less than 10 throw **InsufficientMP**, if **distance** is greater than 5.89 throw **OutOfRange**
 5. If both guard statements pass, return true
 6. Use a **do-catch* statement to call **attackEnemy** and handle each error case individually
 7. Unwrap the optional return value from **attackEnemy** using an **if-let** statement
 
 [Previous Topic](@previous)
 
 */
// 1
enum ActionError: Error {
    case insufficientMP
    case outOfRange
    case unknownError
}
// 2
func attackEnemy(mp: Int, distance: Double) throws -> Bool? {
    guard mp >= 10 else {
        throw ActionError.insufficientMP
    }
    guard distance <= 5.89 else {
        throw ActionError.outOfRange
    }
    return true
}

do {
    let result = try attackEnemy(mp: 9, distance: 5.8)
    if let result = result {
        print("Attack successful!")
    }
} catch ActionError.insufficientMP{
    print("Not enough MP!")
} catch ActionError.outOfRange{
    print("Distance is too far!")
} catch ActionError.unknownError{
    print("Unknown error!")
} catch {
    print("Unknown error!")
}

if let attackSuccess = try? attackEnemy(mp: 55, distance: 7.0) {
    print(attackSuccess ? "Attack successful!" : "Attack failed!")
}
// 3

// 4

// 5

// 6

// 7
