/*:
 # Overloading Functions
 ---
 
 ## Topic Essentials
 Swift will let us have multiple functions with the same name as long as their function type, or signature, is different. This is called function overloading, and is very useful in cases when you may need constant functionality with dependent or computed results.
 
 ### Objectives
 + Create a base function with no parameters or return values
 + Create an overloaded function with an integer parameter
 + Create another overloaded function with two parameters and a return type
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Base function
func attack(){
    print( "Attack!" )
}

// Overloaded functions
func attack(damage: Int){
    print( "Attack! \(damage) damage dealt." )
}

func attack(enemy: String, damage: Int) -> Bool{
    print( "Attack \(enemy)! \(damage) damage dealt." )
    return true;
}

attack()
attack(damage: 10)
var defeated = attack(enemy: "Ogre", damage: 20)
