/*:
 # Complex Functions
 ---
 
 ## Topic Essentials
 Functions in Swift can go from simple to complex very quickly with multiple return types, optionals, and even default values.
 
 ### Objectives
 + Create a new function with an optinal return type
 + Create a an overloaded function with two return values
 + Create another overloaded function with two parameters, both with default values
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Optional return value
func setupArena() -> Bool? {
    return false
}

if let ready = setupArena() {
    print(ready)
} else{
    print("something is wrong")
}
// Multiple return values
func setupArena(level: String) -> (success: Bool, secretItem: String){
    print(level)
    return (true, "Shuriken")
}

var levelDetails = setupArena(level: "Hard")
print(levelDetails.success)
print(levelDetails.secretItem)
// Default values
func setupArenaWitDefault(level: String = "Medium"){
    
    
}
setupArenaWitDefault()
setupArenaWitDefault(level: "Crazy")
