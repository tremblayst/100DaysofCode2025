/*:
 # Type Conversions
 ---
 
 ## Topic Essentials
 Numeric values can be converted to other types using Int, Double, or Float class properties or with explicit syntax. Be aware that in some cases you will need to specify the result type if you want something specific. In other words, the compiler is very smart and will deliver the correct result type, but that might not be the type you want.
 
 ### Objectives
 + Understand explicit conversion and its syntax
 + Convert a Double to an Int and String respectively
 + Concatenate string literals and explicitly casted variables
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)
 
*/
// Test variables
var doubleValue: Double = 3.14


// Explicit conversions
var intValue: Int = Int(doubleValue)
var intValue2 = 6.0
var stringValue: String = String(doubleValue)

// Inferred conversion with operators
var sum = 5 + 5.13
var total = Double(intValue) + doubleValue
var total2: Double = intValue2 + doubleValue


