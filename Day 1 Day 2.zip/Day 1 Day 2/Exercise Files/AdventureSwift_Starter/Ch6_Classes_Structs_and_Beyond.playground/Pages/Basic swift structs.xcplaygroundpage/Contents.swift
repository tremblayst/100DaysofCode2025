/*:
 # Basic Swift Structs
 ---
 
 ## Topic Essentials
 Swift structures share a very similar syntax and functionality, but they are useful for creating different kinds of instances. While classes are well suited to complex data structures and are passed by reference, structs are passed by value and better suited to creating simple instances that don't need inheritance or reference capabilities.
 
 ### Objectives
 + Declare a basic struct called **Level**
 + Assign a few instance properties
 + Define two custom initializers
 + Add non-mutating and mutating functions
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Declaring a new struct
struct Level {
    let levelId: Int
    var levelObjectives: [String]
    var levelDescription: String{
        return "Level \(levelId)"
    }
    
    func queryObjectives(){
        for objective in levelObjectives{
            print(objective)
        }
    }
    
    mutating func completeObjective(index: Int){
        levelObjectives.remove(at: index)
    }
}
var objectives = ["Objective 1", "Objective 2", "Objective 3"]
var level1 = Level(levelId: 1, levelObjectives: objectives)

var defaultlevel = level1
level1.completeObjective(index: 0)
level1.queryObjectives()
defaultlevel.queryObjectives()
// Value types again
