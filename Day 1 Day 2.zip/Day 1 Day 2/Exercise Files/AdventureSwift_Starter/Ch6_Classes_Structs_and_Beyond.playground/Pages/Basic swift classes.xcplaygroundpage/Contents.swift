/*:
 # Basic Swift Classes
 ---
 
 ## Topic Essentials
 Even though swift has an entire library of built-in classes and structs for us to use in our applications, we’ll still need to know how to create our own. These data structures can have properties, methods, initializers, and in the case of classes can have their own subclasses.
 
 ### Objectives
 + Create a simple class called **Adventurer**
 + Declare instance properties with or without values
 + Define designated and convenience initializers
 + Understand reference type behavior
 
 [Next Topic](@next)
 
 */
// Declaring a new class
class Adventurer {
    var name: String
    var health: Int
    
    init(name: String, health: Int) {
        self.name = name
        self.health = health
    }
    
    convenience init(name: String) {
        self.init(name: name, health: 100)
    }
    
    func printStats() {
        print("Name: \(name)")
        print("Health: \(health)")
    }
}

var player1 = Adventurer(name: "Merlin")
player1.printStats()

var player2 = Adventurer(name: "Arthur", health: 80)
player2.printStats()

var defaultPLAYER = player1;
defaultPLAYER.printStats()
defaultPLAYER.health = 200
player1.printStats()

