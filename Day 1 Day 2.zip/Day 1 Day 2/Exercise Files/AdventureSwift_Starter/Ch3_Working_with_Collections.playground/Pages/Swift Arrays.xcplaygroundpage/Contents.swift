/*:
 # Swift Arrays
 ---
 
 ## Topic Essentials
 Swift arrays are **ordered lists**, meaning that the position of each element is determined by the order it was added. Arrays work off of indexes, which can be used to access and modify the values of individual items.
 
 ### Objectives
 + Create arrays with different syntax
 + Add initial values
 + Use the `count` and `isEmpty` methods
 + Access and update array values using subscripts
 
 [Next Topic](@next)
 
 */
// Creating arrays
var levelDificulty: [String] = ["Easy", "Medium", "Hard"]
var array2: Array<Int> = Array<Int>()

// Count and isEmpty
levelDificulty.count
levelDificulty.isEmpty

// Accessing array values
levelDificulty[0]
levelDificulty[1]
levelDificulty[2]
levelDificulty[2] = "Very Hard"
levelDificulty[2]
