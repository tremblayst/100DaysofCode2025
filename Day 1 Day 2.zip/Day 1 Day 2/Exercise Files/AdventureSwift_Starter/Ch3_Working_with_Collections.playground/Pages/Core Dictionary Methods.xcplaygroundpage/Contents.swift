/*:
 # Core Dictionary Methods
 ---
 
 ## Topic Essentials
Dictionary elements can be easily updated and removed using subscript syntax or class methods.
 
 ### Objectives
 + Create a dictionary called **playerStats** and initialize it with key-value pairs
 + Update **playerStats** using different methods
 + Remove key-value pairs from **playerStats** using different methods
 + Create a 2 dimensional dictionary called **questDict** and populate it
 + Use chained subcripts to access a nested key-value pair
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Caching and overwriting items
 var playerStats: [String: Int] = ["Wins": 10, "Losses": 2, "Eliminations": 80]

var oldValue = playerStats.updateValue(11, forKey: "Wins")
// Caching and removing items
playerStats["Wins"] = nil
playerStats.removeValue(forKey: "Losses")

// Nested dictionaries

var questBoard = [
    "Knights Quest":[
        "Objective": "Defeat the Dragon",
        "Reward": "Dragon Scale Mail"
    ],
    "Elven Lair Quest":[
        "Objective": "Collect 5 Gems",
        "Reward": "Elven Longbow"
    ]
]

var objetive = questBoard["Knights Quest"]?["Objective"]
