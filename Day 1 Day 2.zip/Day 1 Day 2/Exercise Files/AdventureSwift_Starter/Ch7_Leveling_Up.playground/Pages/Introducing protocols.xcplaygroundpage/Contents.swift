/*:
 # Introducing Protocols
 ---
 
 ## Topic Essentials
 Swift protocols are essentially groups of properties and behaviors that can be adopted by a class or struct. If a class or struct implements a protocol, that class or struct enters into an agreement that says they will follow the blueprint the protocol has set out.
 
 ### Objectives
 + Declare a protocol
 + Add properties, a function and an initializer
 + Create a struct that adopts the protocol
 + Adopt multiple protocols
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Declare a protocol
protocol Collectable {
    var name: String { get }
    var price: Int { get set}
    
    func collect() -> Bool
}

extension Collectable {
    var priceIncrease: Int {
        return self.price * 10
    }
    
    func collect() -> Bool {
        print( "Not Collected \(self.name)")
        return false
    }
}

protocol Usable {
    func use() -> Bool
}

// Protocol adoption
class Item: Collectable, Usable {
    func use() -> Bool {
        return true;
    }
    
    var name: String
    var price: Int
    
    init(name: String, price: Int) {
        self.name = name
        self.price = price
    }
    
    //func collect() -> Bool {
    //    return true;
    //}
}

let potion = Item(name: "Potion of Health", price: 100)
potion.collect()
potion.priceIncrease

extension String{
    func fancyDebug(){
        print("💎 \(self) 💎")
    }
}
potion.name.fancyDebug()
