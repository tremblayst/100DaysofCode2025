/*:
 # Handling Errors
 ---
 
 ## Topic Essentials
 Errors that are thrown from functions need to be handled with a combination of the **try** keyword and a **do-catch** statement. The idea behind this is delegation - where do we want to send out an error and how does it need to be addressed.
 
 ### Objectives
 + Understand error propagation
 + Use the **do-catch** statement to handle errors effectively
 
 [Previous Topic](@previous)
 
 */
// Test code
enum DataError: Error {
    case EmptyPath
    case InvalidPath
}

let playerDataPath = "/player_data.json"


func loadData(path: String) throws -> Bool? {
    guard path.contains("/") else {
        throw DataError.InvalidPath
    }
    
    guard !path.isEmpty else {
        throw DataError.EmptyPath
    }
    
    return true
}

// Do-Catch statements
do{
    try loadData(path: playerDataPath)
    print("Data loaded successfully")
} catch is DataError {
    print("Error loading data")
} catch {
    print("An unexpected error occurred: \(error)")
}

if let dataLoaded = try? loadData(path: playerDataPath) {
    print("load data worked")
}

// Propagating errors
func propagateDataError() throws {
    try loadData(path: playerDataPath)
}

do {
    try propagateDataError()
    print( "Data loaded successfully")
} catch DataError.EmptyPath {
    print("empty path")
} catch DataError.InvalidPath {
    print ("invalid path")
} catch {
    print("An error occurred: \(error)")
    throw error
}
