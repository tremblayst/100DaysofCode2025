/*:
 # Raw and Associated Values
 ---
 
 ## Topic Essentials
 Enumerations can be expanded to include raw values, which can store unique or sequential values, or associated values, which can capture case specific parameters for use in their respective code blocks.
 
 ### Objectives
 + Declare an enum with a raw value
 + Declare an enum with associated values
 + Add a method inside the enum to execute a switch statement for each case
 
 [Previous Topic](@previous)                                                 [Next Topic](@next)

 */
// Raw values
enum NonPlayableCharacters : String {
    case aragorn = "Strider"
    case legolas = "Elf Prince"
    case gimli = "Dwarf Warrior"
}

var aragorn: NonPlayableCharacters = .aragorn
print(aragorn.rawValue)


// Associated values
enum PlayerState{
    case Alive
    case Dead(reason: String)
    case Unknown(debugError: String)
    
    func evaluateCase(){
        switch self {
        case .Alive:
            print("Player is alive")
        case .Dead(reason: let reason):
            print("Player is dead: \(reason)")
        case .Unknown(debugError: let debugError):
            print("Player state is unknown: \(debugError)")
        }
    }
}
 
PlayerState.Dead(reason: "Poison").evaluateCase()
